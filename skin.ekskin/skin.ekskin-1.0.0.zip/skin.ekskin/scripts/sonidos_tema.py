# -*- coding: utf-8 -*-
"""Ajuste "Sonidos al cambiar de tema" y generación de los WAV con barra de progreso.

Los WAV (3,5 MB) no van en el zip: se sintetizan al activar el ajuste y se guardan en addon_data,
que sobrevive a las actualizaciones de la skin.
Uso: RunScript(special://skin/scripts/sonidos_tema.py,alternar|generar)
"""
import os
import sys
import time

import xbmc
import xbmcgui
import xbmcvfs

import sintetizador

AJUSTE = "sonidos_tema"
CARPETA = "special://profile/addon_data/skin.ekskin/sonidos/"
MARCA = "version.txt"
CERROJO = "ekskin.generando_sonidos"
BARRA_VISIBLE = "Window.IsVisible(extendedprogressdialog)"


class Cancelado(Exception):
    pass


def texto(id_texto, por_defecto):
    # getLocalizedString solo ve los strings de la skin en algunas versiones de Kodi
    return xbmc.getLocalizedString(id_texto) or por_defecto


def activado():
    return xbmc.getCondVisibility(f"Skin.HasSetting({AJUSTE})")


def ruta(nombre):
    return f"{CARPETA}{nombre}.wav"


def listos():
    carpeta = xbmcvfs.translatePath(CARPETA)
    try:
        with open(os.path.join(carpeta, MARCA), encoding="utf-8") as f:
            if f.read().strip() != sintetizador.VERSION:
                return False
    except OSError:
        return False
    return all(os.path.isfile(os.path.join(carpeta, f"{n}.wav")) for n in sintetizador.SONIDOS)


class Barra:
    """DialogProgressBG que se vuelve a crear si ReloadSkin (un cambio de tema) la cierra."""

    def __init__(self, titulo):
        self.titulo = titulo
        self._crear("")

    def _crear(self, mensaje):
        self.dialogo = xbmcgui.DialogProgressBG()
        self.dialogo.create(self.titulo, mensaje)
        self.creada = time.time()

    def poner(self, porcentaje, mensaje):
        # Recién creada tarda un momento en aparecer, por eso no se mira antes de 1 s
        if time.time() - self.creada > 1 and not xbmc.getCondVisibility(BARRA_VISIBLE):
            self.dialogo.close()
            self._crear(mensaje)
        self.dialogo.update(int(porcentaje), message=mensaje)

    def cerrar(self):
        self.dialogo.close()


def borrar_temporales_viejos(carpeta):
    # Restos de una generación cortada. Solo los de más de una hora: uno reciente puede ser de otra pasada en marcha
    for nombre in os.listdir(carpeta):
        ruta_tmp = os.path.join(carpeta, nombre)
        if nombre.endswith(".tmp") and time.time() - os.path.getmtime(ruta_tmp) > 3600:
            os.remove(ruta_tmp)


def generar():
    casa = xbmcgui.Window(10000)
    if casa.getProperty(CERROJO):
        return
    casa.setProperty(CERROJO, "1")
    monitor = xbmc.Monitor()
    try:
        # Apagar y reactivar el ajuste durante una pasada la cancela, y la segunda llamada sale por el
        # cerrojo: por eso se reintenta una vez en vez de dejar los sonidos a medias
        for _ in range(2):
            if monitor.abortRequested() or not activado() or listos():
                break
            una_pasada(monitor)
    finally:
        casa.clearProperty(CERROJO)


def una_pasada(monitor):
    carpeta = xbmcvfs.translatePath(CARPETA)
    barra = None
    try:
        os.makedirs(carpeta, exist_ok=True)
        borrar_temporales_viejos(carpeta)
        marca = os.path.join(carpeta, MARCA)
        if os.path.exists(marca):
            os.remove(marca)  # sin marca, listos() es falso y una pasada cortada se rehace entera
        barra = Barra(texto(31743, "Generating theme sounds"))
        espera = texto(31744, "Only once; it may take a few minutes")
        nombres = list(sintetizador.SONIDOS)
        for k, nombre in enumerate(nombres):
            mensaje = f"{k + 1}/{len(nombres)} · {espera}"

            def aviso(fraccion, k=k, mensaje=mensaje):
                if monitor.abortRequested() or not activado():
                    raise Cancelado
                barra.poner(100 * (k + fraccion) / len(nombres), mensaje)

            # El pid no sirve para distinguir pasadas: todos los scripts de Kodi comparten proceso.
            # Con nombres distintos, dos pasadas simultáneas no se pisan y os.replace deja el mismo WAV.
            temporal = os.path.join(carpeta, f"{nombre}.{os.urandom(6).hex()}.tmp")
            try:
                sintetizador.generar(nombre, temporal, aviso)
                os.replace(temporal, os.path.join(carpeta, f"{nombre}.wav"))
            finally:
                if os.path.exists(temporal):
                    os.remove(temporal)
        with open(marca, "w", encoding="utf-8") as f:
            f.write(sintetizador.VERSION)
        barra.cerrar()
        barra = None
        xbmcgui.Dialog().notification(texto(31742, "Sounds when changing theme"),
                                      texto(31745, "Theme sounds ready"), xbmcgui.NOTIFICATION_INFO, 3000)
    except Cancelado:
        xbmc.log("EKSkin: generación de sonidos cancelada", xbmc.LOGINFO)
    except (OSError, MemoryError) as error:
        # Se apaga el ajuste: si no, cada cambio de tema relanzaría la generación y volvería a fallar
        xbmc.log(f"EKSkin: no se pudieron generar los sonidos: {error!r}", xbmc.LOGERROR)
        xbmc.executebuiltin(f"Skin.Reset({AJUSTE})", True)
        xbmcgui.Dialog().notification(texto(31742, "Sounds when changing theme"),
                                      texto(31746, "Could not generate the sounds"), xbmcgui.NOTIFICATION_ERROR, 5000)
    finally:
        if barra is not None:
            barra.cerrar()


def alternar():
    if activado():
        # Los WAV se conservan: al reactivarlo no hay que generarlos de nuevo
        xbmc.executebuiltin(f"Skin.Reset({AJUSTE})", True)
        return
    xbmc.executebuiltin(f"Skin.SetBool({AJUSTE})", True)
    if not listos():
        generar()


if __name__ == "__main__":
    orden = sys.argv[1] if len(sys.argv) > 1 else ""
    if orden == "alternar":
        alternar()
    elif orden == "generar" and activado() and not listos():
        generar()
