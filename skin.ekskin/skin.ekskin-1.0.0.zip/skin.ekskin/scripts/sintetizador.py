# -*- coding: utf-8 -*-
"""Sintetizador de los sonidos de cambio de tema.

Cada tema tiene una melodía propia escrita a partir de la tonalidad, el compás y el registro que
se publican de su arranque clásico; ninguna fuente da las notas exactas.

Salida: WAV PCM de 16 bits, estéreo, 32 kHz. Con xbmc.playSFX en Kodi 21.3 solo suena el WAV PCM:
OGG cierra Kodi, MP3 no se decodifica y µ-law/A-law se descartan.
Python puro (el de Kodi es el 3.8 y no trae numpy). La cabecera WAV se escribe a mano porque el
módulo wave importa audioop, que no todas las compilaciones de Kodi incluyen.
"""
import math
import random
import struct
import sys
from array import array

# Subirla al cambiar un sonido: Kodi regenera los que ya estaban guardados
VERSION = "1"

FR = 32000
NYQUIST_UTIL = 0.45 * FR  # por encima de esto los armónicos se pliegan (aliasing)
RMS_OBJETIVO = 0.14  # mismo nivel medio en los siete
PICO_MAX = 0.89
DOS_PI = 2 * math.pi

SEMITONOS = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5, "F#": 6,
             "Gb": 6, "G": 7, "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}

# Cada receta se ejecuta dos veces: la primera "en seco", sin calcular, solo para contar los pasos,
# y la segunda de verdad, avisando del avance. El aviso puede lanzar una excepción para cancelar.
_estado = {"seco": False, "hechos": 0, "total": 1, "aviso": None, "destino": None}


def _paso():
    _estado["hechos"] += 1
    if _estado["aviso"] is not None:
        _estado["aviso"](min(1.0, _estado["hechos"] / _estado["total"]))


def hz(nombre):
    # "Bb4" -> 466,16 Hz
    return 440.0 * 2 ** ((12 * (int(nombre[-1]) + 1) + SEMITONOS[nombre[:-1]] - 69) / 12)


def envolvente(i, n, ataque, caida, liberacion):
    t = i / FR
    subida = min(1.0, t / ataque) if ataque > 0 else 1.0
    bajada = min(1.0, (n - i) / (liberacion * FR)) if liberacion > 0 else 1.0
    return subida * bajada * math.exp(-t * caida)


# Instrumentos: devuelven una lista de muestras mono

def campana(nombre, dur, indice=2.0, razon=3.5, caida=1.5, caida_indice=3.0, ataque=0.002, desafinar=0.0):
    # Campana FM: el índice de modulación decae más rápido que la amplitud, así el brillo del ataque se apaga antes que el tono
    if _estado["seco"]:
        return []
    f = hz(nombre) * (1 + desafinar)
    fm = f * razon
    indice = max(0.3, min(indice, (NYQUIST_UTIL - f) / fm - 1))
    n = int(dur * FR)
    w, wm = DOS_PI * f / FR, DOS_PI * fm / FR
    return [envolvente(i, n, ataque, caida, 0.15) * math.sin(w * i + indice * math.exp(-i / FR * caida_indice) * math.sin(wm * i))
            for i in range(n)]


def piano(nombre, dur, caida=1.8, brillo=1.0, desafinar=0.0):
    # Piano eléctrico FM: modulador 1:1 que se apaga rápido y un "tine" 14:1 brevísimo para el golpe del martillo
    if _estado["seco"]:
        return []
    f = hz(nombre) * (1 + desafinar)
    n = int(dur * FR)
    w = DOS_PI * f / FR
    con_tine = 14 * f < NYQUIST_UTIL
    out = []
    for i in range(n):
        t = i / FR
        mod = 1.6 * brillo * math.exp(-t * 5) * math.sin(w * i)
        if con_tine:
            mod += 0.5 * brillo * math.exp(-t * 35) * math.sin(14 * w * i)
        out.append(envolvente(i, n, 0.003, caida, 0.2) * math.sin(w * i + mod))
    return out


def pad(notas, dur, ataque=0.6, liberacion=1.2, caida=0.0, armonicos=6, desafinar=0.004, lado=1):
    # Pad por síntesis aditiva (armónicos 1/k^1.4, una sierra suave) con dos voces desafinadas por nota.
    # `lado` invierte el signo de la desafinación: cada canal suena distinto y el estéreo se abre.
    if _estado["seco"]:
        return []
    n = int(dur * FR)
    out = [0.0] * n
    voces = []
    for nombre in notas:
        f = hz(nombre)
        for d in (1 - desafinar * lado, 1 + desafinar * 0.6 * lado):
            for k in range(1, armonicos + 1):
                if f * d * k < NYQUIST_UTIL:
                    voces.append((DOS_PI * f * d * k / FR, 1 / k ** 1.4, random.Random(k + len(voces)).random() * DOS_PI))
    escala = 1 / max(1, len(notas))
    for i in range(n):
        s = 0.0
        for w, a, fase in voces:
            s += a * math.sin(w * i + fase)
        out[i] = s * escala * envolvente(i, n, ataque, caida, liberacion)
    return out


def pasabanda(x, fc, q):
    # Biquad pasabanda del Audio EQ Cookbook (R. Bristow-Johnson)
    w0 = DOS_PI * fc / FR
    alfa = math.sin(w0) / (2 * q)
    a0 = 1 + alfa
    b0, b2 = alfa / a0, -alfa / a0
    a1, a2 = -2 * math.cos(w0) / a0, (1 - alfa) / a0
    y = [0.0] * len(x)
    x1 = x2 = y1 = y2 = 0.0
    for i, v in enumerate(x):
        s = b0 * v + b2 * x2 - a1 * y1 - a2 * y2
        x2, x1, y2, y1 = x1, v, y1, s
        y[i] = s
    return y


def tambor(f0, f1, dur, cuero=1.0, palmada=0.0, centro_palmada=900, semilla=1):
    # Djembé: la membrana baja de f0 a f1 y se le suma el chasquido de la mano (ruido filtrado)
    if _estado["seco"]:
        return []
    n = int(dur * FR)
    azar = random.Random(semilla)
    ruido = [azar.uniform(-1, 1) * math.exp(-i / FR * 45) for i in range(n)]
    chasquido = pasabanda(ruido, centro_palmada, 2.5)
    out = []
    fase = 0.0
    for i in range(n):
        t = i / FR
        fase += DOS_PI * (f1 + (f0 - f1) * math.exp(-t * 25)) / FR
        membrana = math.sin(fase) * math.exp(-t * 6.5) + 0.3 * math.sin(2.3 * fase) * math.exp(-t * 14)
        out.append(cuero * membrana * min(1.0, t / 0.001) + palmada * 6 * chasquido[i])
    return out


def soplo(dur, fc, q=1.2, vol=1.0, ataque=0.8, liberacion=1.0, semilla=3):
    # Ruido filtrado con ataque lento: la brisa de fondo de XP y 7
    if _estado["seco"]:
        return []
    azar = random.Random(semilla)
    n = int(dur * FR)
    ruido = pasabanda([azar.uniform(-1, 1) for _ in range(n)], fc, q)
    return [v * vol * envolvente(i, n, ataque, 0.0, liberacion) for i, v in enumerate(ruido)]


class Mezcla:
    def __init__(self, segundos):
        n = 1 if _estado["seco"] else int(segundos * FR)
        self.l, self.r = [0.0] * n, [0.0] * n

    def poner(self, t0, muestras, pan=0.0, vol=1.0):
        # pan de -1 (izquierda) a 1 (derecha), ley de potencia constante
        a = (pan + 1) * math.pi / 4
        gl, gr = math.cos(a) * vol, math.sin(a) * vol
        n0 = int(t0 * FR)
        for i, v in enumerate(muestras[:max(0, len(self.l) - n0)]):
            self.l[n0 + i] += v * gl
            self.r[n0 + i] += v * gr
        _paso()

    def poner_pad(self, t0, notas, dur, vol=1.0, **kw):
        # Un pad por canal con desafinación opuesta (ver pad)
        self.poner(t0, pad(notas, dur, lado=1, **kw), pan=-0.7, vol=vol)
        self.poner(t0, pad(notas, dur, lado=-1, **kw), pan=0.7, vol=vol)


def peine(x, d, fb, amort):
    y = [0.0] * len(x)
    buf = [0.0] * d
    filtro = 0.0
    j = 0
    for i, v in enumerate(x):
        salida = buf[j]
        filtro = salida * (1 - amort) + filtro * amort
        buf[j] = v + filtro * fb
        j = j + 1 if j + 1 < d else 0
        y[i] = salida
    return y


def pasatodo(x, d, g=0.5):
    y = [0.0] * len(x)
    buf = [0.0] * d
    j = 0
    for i, v in enumerate(x):
        b = buf[j]
        y[i] = b - v
        buf[j] = v + b * g
        j = j + 1 if j + 1 < d else 0
    return y


def rms(x):
    return math.sqrt(sum(v * v for v in x) / len(x)) or 1e-9


PEINES = (1116, 1188, 1277, 1356, 1422, 1491)


def reverb(m, mezcla, sala=0.84, amort=0.3):
    # Freeverb reducido: la suma mono alimenta un tanque por canal, con retardos distintos para que la cola sea estéreo
    if _estado["seco"]:
        for _ in range(2 * len(PEINES)):
            _paso()
        return
    entrada = [(a + b) * 0.5 for a, b in zip(m.l, m.r)]
    escala = FR / 44100
    for canal, extra in (("l", 0), ("r", 23)):
        humedo = [0.0] * len(entrada)
        for d in PEINES:
            for i, v in enumerate(peine(entrada, int((d + extra) * escala), sala, amort)):
                humedo[i] += v
            _paso()
        for d in (556, 441, 341, 225):
            humedo = pasatodo(humedo, int((d + extra) * escala))
        seco = getattr(m, canal)
        g = rms(seco) / rms(humedo)  # iguala el nivel de la cola al de la señal seca antes de mezclar
        setattr(m, canal, [s * (1 - mezcla) + h * g * mezcla for s, h in zip(seco, humedo)])


def guardar(m, mezcla=0.3, sala=0.84):
    reverb(m, mezcla, sala)
    if _estado["seco"]:
        _paso()
        return
    # Recorta el silencio final: descarta las ventanas de 50 ms que están 30 dB por debajo del nivel medio
    ventana = int(0.05 * FR)
    umbral = 0.03 * max(rms(m.l), rms(m.r))
    ultima = 0
    for ini in range(0, len(m.l) - ventana, ventana):
        if max(rms(m.l[ini:ini + ventana]), rms(m.r[ini:ini + ventana])) > umbral:
            ultima = ini + ventana
    fin = min(len(m.l), ultima + int(0.2 * FR))
    l, r = m.l[:fin], m.r[:fin]
    g = min(RMS_OBJETIVO / math.sqrt((rms(l) ** 2 + rms(r) ** 2) / 2),
            PICO_MAX / max(max(abs(v) for v in l), max(abs(v) for v in r)))
    cola = int(0.3 * FR)
    muestras = array("h", [0]) * (2 * fin)
    for i in range(fin):
        fundido = min(1.0, i / 64, (fin - i) / cola)
        muestras[2 * i] = int(l[i] * g * fundido * 32767)
        muestras[2 * i + 1] = int(r[i] * g * fundido * 32767)
    if sys.byteorder == "big":
        muestras.byteswap()  # WAV es little-endian
    datos = muestras.tobytes()
    cabecera = struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36 + len(datos), b"WAVE", b"fmt ", 16, 1, 2,
                           FR, FR * 4, 4, 16, b"data", len(datos))
    with open(_estado["destino"], "wb") as f:
        f.write(cabecera)
        f.write(datos)
    _paso()


def tema_95():
    # Win95 (Brian Eno): Si bemol mayor, 177 ppm, melodía por grados conjuntos entre Sol4 y Sol5,
    # acordes Sib, Mib y Fa. La EnoFAQ (web de fans) lo resume como "boong-bliiiing-tink-tink-tink".
    m = Mezcla(5.2)
    m.poner_pad(0.0, ["Bb1", "F2", "Bb2"], 3.0, vol=0.9, ataque=0.05, caida=0.9, liberacion=1.5, armonicos=5)
    m.poner_pad(0.25, ["Eb4", "G4", "Bb4", "D5"], 4.4, vol=0.3, ataque=1.0, liberacion=2.2, armonicos=4, desafinar=0.006)
    m.poner(0.34, campana("G5", 4.2, indice=2.2, razon=2.0, caida=0.8, caida_indice=1.2), pan=-0.2, vol=0.75)
    m.poner(0.36, campana("D6", 3.8, indice=1.2, razon=2.0, caida=1.0, caida_indice=1.5, desafinar=0.002), pan=0.3, vol=0.35)
    for k, (nota, pan) in enumerate((("F5", -0.55), ("D5", 0.55), ("Bb4", 0.0))):
        m.poner(1.36 + k * 0.17, campana(nota, 2.0, indice=3.0, razon=3.5, caida=2.6, caida_indice=8), pan=pan, vol=0.45)
    m.poner_pad(1.36, ["F4", "A4", "C5"], 3.4, vol=0.15, ataque=0.6, liberacion=2.0, armonicos=3)
    guardar(m, mezcla=0.38, sala=0.88)


def tema_xp():
    # XP (Bill Brown): Mi bemol mayor en 6/8, melodía entre Mib5 y Mib6, acordes Fam, Lab y Mib.
    m = Mezcla(5.4)
    o = 0.27  # corchea
    m.poner(0.0, soplo(2.4, 1800, vol=0.08, ataque=1.2, liberacion=1.0))
    m.poner_pad(0.0, ["F3", "Ab3", "C4", "F4"], 1.3, vol=0.45, ataque=0.25, liberacion=0.45)
    m.poner_pad(3 * o, ["Ab3", "C4", "Eb4", "Ab4"], 1.3, vol=0.45, ataque=0.2, liberacion=0.5)
    m.poner_pad(6 * o, ["Eb3", "G3", "Bb3", "Eb4", "G4"], 3.6, vol=0.55, ataque=0.15, liberacion=2.4)
    m.poner_pad(6 * o, ["Eb2"], 3.4, vol=0.35, ataque=0.1, liberacion=2.4, armonicos=3)
    for k, (nota, pan) in enumerate((("C6", -0.4), ("Ab5", 0.4), ("F5", 0.0),
                                      ("Eb6", -0.4), ("C6", 0.4), ("Ab5", 0.0))):
        m.poner(k * o, piano(nota, 1.6, caida=2.2, brillo=0.8), pan=pan, vol=0.42)
        m.poner(k * o, campana(nota, 1.2, indice=1.0, razon=4.0, caida=3.5, caida_indice=6), pan=-pan, vol=0.12)
    for nota, pan in (("G5", -0.35), ("Bb5", 0.35), ("Eb6", 0.0)):
        m.poner(6 * o, piano(nota, 3.4, caida=1.1, brillo=0.7), pan=pan, vol=0.42)
        m.poner(6 * o, campana(nota, 3.0, indice=1.2, razon=2.0, caida=1.2, caida_indice=2), pan=-pan, vol=0.14)
    guardar(m, mezcla=0.32, sala=0.86)


def tema_7():
    # Win7: Mi mayor, 121 ppm, aireado como el de 95; abre con dos notas que suben. Acordes Mi, La y Si.
    m = Mezcla(5.0)
    c = 0.248  # corchea
    m.poner(0.0, soplo(3.0, 2400, vol=0.06, ataque=1.0, liberacion=1.4))
    m.poner_pad(0.0, ["E3", "B3", "E4", "G#4"], 4.2, vol=0.5, ataque=0.7, liberacion=2.4, desafinar=0.005)
    m.poner_pad(0.0, ["E2"], 3.8, vol=0.4, ataque=0.5, liberacion=2.0, armonicos=3)
    for t, nota, pan, vol in ((0.05, "B4", -0.3, 0.6), (0.05 + 2 * c, "E5", 0.3, 0.65),
                              (0.05 + 4 * c, "G#5", -0.45, 0.45), (0.05 + 5 * c, "B5", 0.45, 0.45),
                              (0.05 + 6 * c, "E6", 0.0, 0.4)):
        m.poner(t, campana(nota, 3.4, indice=1.4, razon=2.0, caida=1.1, caida_indice=2.2), pan=pan, vol=vol)
        m.poner(t, campana(nota, 2.0, indice=0.8, razon=5.0, caida=3.0, caida_indice=6, desafinar=0.003), pan=-pan, vol=vol * 0.25)
    guardar(m, mezcla=0.42, sala=0.9)


def tema_10():
    # Win10: sin análisis publicado, así que es libre: Re mayor y dos notas que suben, como el de 7 pero más sobrio.
    m = Mezcla(4.0)
    m.poner_pad(0.0, ["D3", "A3", "D4", "F#4"], 3.0, vol=0.5, ataque=0.35, liberacion=1.8)
    m.poner(0.05, campana("A4", 2.8, indice=1.4, razon=2.0, caida=1.4, caida_indice=2.5), pan=-0.3, vol=0.6)
    m.poner(0.27, campana("D5", 2.8, indice=1.4, razon=2.0, caida=1.3, caida_indice=2.5), pan=0.3, vol=0.65)
    m.poner(0.49, campana("F#5", 2.6, indice=1.0, razon=2.0, caida=1.4, caida_indice=3), pan=-0.4, vol=0.35)
    m.poner(0.49, campana("A5", 2.6, indice=1.0, razon=2.0, caida=1.4, caida_indice=3), pan=0.4, vol=0.35)
    guardar(m, mezcla=0.34, sala=0.86)


def tema_11():
    # Win11: Fa sostenido menor, 214 ppm, registro grave (Fa#3 a Sol#4), solo notas del acorde.
    m = Mezcla(4.2)
    c = 0.14  # corchea
    m.poner_pad(0.0, ["F#2", "C#3", "A3"], 3.2, vol=0.5, ataque=0.25, liberacion=2.0, armonicos=4)
    for k, (nota, pan) in enumerate((("F#3", -0.2), ("C#4", 0.2), ("F#4", -0.3), ("G#4", 0.3))):
        m.poner(0.02 + k * c, piano(nota, 2.6, caida=1.5, brillo=0.6), pan=pan, vol=0.6)
        m.poner(0.02 + k * c, campana(nota, 1.6, indice=0.8, razon=4.0, caida=2.6, caida_indice=7), pan=-pan, vol=0.18)
    m.poner(0.02 + 4 * c, piano("C#5", 2.4, caida=1.6, brillo=0.5), pan=0.0, vol=0.3)
    guardar(m, mezcla=0.3, sala=0.85)


def tema_linux():
    # Ubuntu: los tambores de "system-ready", como golpes de djembé con mucha reverb.
    m = Mezcla(3.2)
    golpes = ((0.00, 330, 210, 0.3, 1.0, 1100, -0.3),   # palmadas agudas
              (0.13, 330, 210, 0.3, 0.9, 1100, 0.3),
              (0.26, 250, 160, 0.7, 0.5, 800, -0.1),    # tono medio
              (0.42, 160, 85, 1.0, 0.25, 600, 0.0),     # bajo
              (0.72, 250, 160, 0.7, 0.6, 850, 0.2),
              (0.85, 150, 80, 1.0, 0.3, 600, 0.0))      # bajo final, el que queda resonando
    for k, (t, f0, f1, cuero, palmada, centro, pan) in enumerate(golpes):
        m.poner(t, tambor(f0, f1, 1.4, cuero=cuero, palmada=palmada, centro_palmada=centro, semilla=k + 1), pan=pan, vol=0.9)
    guardar(m, mezcla=0.36, sala=0.86)


def tema_mac():
    # Mac: acorde de Fa sostenido mayor (el original es un Do mayor de un teclado Korg subido de tono).
    m = Mezcla(5.0)
    for k, nota in enumerate(("F#2", "C#3", "F#3", "A#3", "C#4", "F#4")):
        for desv, pan in ((-0.0015, -0.5), (0.0015, 0.5)):
            m.poner(0.0, piano(nota, 4.4, caida=0.75, brillo=1.1 - k * 0.08, desafinar=desv), pan=pan, vol=0.5 - k * 0.04)
    m.poner_pad(0.0, ["F#3", "C#4", "F#4", "A#4"], 4.0, vol=0.25, ataque=0.01, caida=0.6, liberacion=2.0, armonicos=8)
    guardar(m, mezcla=0.3, sala=0.86)


# Nombre del archivo -> receta, en el orden en que se generan
SONIDOS = {"tema_95": tema_95, "tema_xp": tema_xp, "tema_7": tema_7, "tema_10": tema_10,
           "tema_11": tema_11, "tema_linux": tema_linux, "tema_mac": tema_mac}


def generar(nombre, destino, aviso=None):
    """Escribe el WAV `nombre` en `destino`. `aviso(fraccion)` recibe el avance de 0 a 1."""
    receta = SONIDOS[nombre]
    _estado.update(seco=True, hechos=0, total=1, aviso=None, destino=None)
    receta()
    _estado.update(seco=False, total=max(1, _estado["hechos"]), hechos=0, aviso=aviso, destino=destino)
    try:
        receta()
    finally:
        _estado.update(aviso=None, destino=None)
