# -*- coding: utf-8 -*-
import sys

import xbmc
import xbmcgui

from cambiar_tema import aplicar


def texto(id_texto, por_defecto):
    # getLocalizedString solo ve los strings de la skin en algunas versiones de
    # Kodi; el respaldo evita dejar los diálogos en blanco.
    return xbmc.getLocalizedString(id_texto) or por_defecto


def main():
    tema = sys.argv[1] if len(sys.argv) > 1 else "mac"
    if tema not in ("mac", "win11"):
        return
    titulo = texto(31730, "Variante del tema")
    # Sin preselect: la opcion preseleccionada usa selectedcolor, que en la skin es el color de texto
    # normal (Defaults.xml), y sobre la barra de foco no se leia.
    # ○ y ● representan claro y oscuro; no marcan la variante que esta puesta.
    opciones = [f"○ {texto(31731, 'Clara')}", f"● {texto(31732, 'Oscura')}"]
    elegida = xbmcgui.Dialog().select(titulo, opciones)
    if elegida < 0:
        return

    # Se cierra antes de aplicar: aplicar() puede tardar y el selector abierto admitiría un segundo clic
    xbmc.executebuiltin("Dialog.Close(1113)")
    aplicar(tema, oscuro=elegida == 1)


main()
