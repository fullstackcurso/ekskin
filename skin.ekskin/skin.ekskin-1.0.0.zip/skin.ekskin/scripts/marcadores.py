# -*- coding: utf-8 -*-
import json
import os
import re
import sys

import xbmc
import xbmcgui
import xbmcvfs

MAXIMO = 10
FICHERO = "special://profile/addon_data/skin.ekskin/marcadores.json"


def texto(id_texto, por_defecto):
    # getLocalizedString solo ve los strings de la skin en algunas versiones de
    # Kodi; el respaldo evita dejar los diálogos en blanco.
    return xbmc.getLocalizedString(id_texto) or por_defecto


def limpiar(nombre):
    # Algunos add-ons meten BBCode en FolderName (AtresDaily); Kodi solo lo
    # interpreta al pintarlo y el marcador se guardaría con las etiquetas.
    etiquetas = (r"\[/?(?:B|I|COLOR|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT"
                 r"|TABS|CR)(?: [^\]]*)?\]")
    return re.sub(etiquetas, "", nombre, flags=re.IGNORECASE).strip()


def avisar(mensaje):
    xbmcgui.Dialog().notification(texto(31710, "Marcadores"), mensaje,
                                  xbmcgui.NOTIFICATION_INFO, 5000)


def leer():
    ruta = xbmcvfs.translatePath(FICHERO)
    if not xbmcvfs.exists(ruta):
        return []
    try:
        with open(ruta, encoding="utf-8") as fichero:
            datos = json.load(fichero)
    except (OSError, ValueError):
        return None
    if not isinstance(datos, list):
        return None
    return [m for m in datos
            if isinstance(m, dict) and m.get("path") and m.get("name") and m.get("win")]


def escribir(marcadores):
    ruta = xbmcvfs.translatePath(FICHERO)
    xbmcvfs.mkdirs(os.path.dirname(ruta))
    # Se escribe aparte y se sustituye de golpe: si Kodi se cierra a mitad, el
    # fichero bueno sigue entero.
    temporal = f"{ruta}.tmp"
    try:
        with open(temporal, "w", encoding="utf-8") as fichero:
            json.dump(marcadores, fichero, ensure_ascii=False, indent=2)
        os.replace(temporal, ruta)
    except OSError as error:
        xbmc.log(f"[EKSkin] No se pudieron guardar los marcadores: {error}", xbmc.LOGWARNING)
        return False
    return True


def apartar_ilegible():
    # Antes de guardar nada: si no, el siguiente marcador sobrescribiría la lista rota
    # y se perderían los anteriores, que en el .bak aún se pueden recuperar a mano.
    ruta = xbmcvfs.translatePath(FICHERO)
    try:
        os.replace(ruta, f"{ruta}.bak")
    except OSError as error:
        xbmc.log(f"[EKSkin] No se pudo apartar {ruta}: {error}", xbmc.LOGWARNING)
        return False
    xbmc.log(f"[EKSkin] Marcadores ilegibles apartados en {ruta}.bak", xbmc.LOGWARNING)
    return True


def guardar(carpeta, nombre, ventana, marcadores):
    if not carpeta:
        avisar(texto(31721, "Esta ventana no tiene una carpeta que guardar."))
        return
    if any(m["path"] == carpeta for m in marcadores):
        avisar(texto(31713, "Esta carpeta ya está guardada."))
        return
    if len(marcadores) >= MAXIMO:
        avisar(texto(31712, "Máximo 10 marcadores, borra uno."))
        return
    nombre = xbmcgui.Dialog().input(texto(31722, "Nombre del marcador"),
                                    defaultt=nombre or carpeta)
    if not nombre:
        return
    marcadores.append({"name": nombre, "path": carpeta, "win": ventana})
    if escribir(marcadores):
        avisar(texto(31717, "Marcador guardado."))
    else:
        avisar(texto(31719, "No se pudieron guardar los marcadores."))


def main():
    if len(sys.argv) < 3:
        return
    carpeta, nombre = sys.argv[1], sys.argv[2]
    # En los plugins FolderName es siempre el nombre del add-on; la categoria que fija
    # el plugin (setPluginCategory) dice en que subcarpeta se esta.
    if len(sys.argv) > 3 and sys.argv[3]:
        nombre = f"{nombre} · {sys.argv[3]}" if nombre else sys.argv[3]
    nombre = limpiar(nombre)
    # Antes de abrir los select, que traen su propia ventana: aquí sigue activa
    # la vista en la que se pulsó el botón.
    ventana = xbmcgui.getCurrentWindowId()

    marcadores = leer()
    if marcadores is None:
        avisar(texto(31720, "No se pudo leer la lista de marcadores."))
        # Si ni siquiera se puede apartar, se para aquí para no sobrescribirla.
        if not apartar_ilegible():
            return
        marcadores = []

    opciones = [texto(31711, "Guardar esta carpeta")]
    opciones += [m["name"] for m in marcadores]
    elegido = xbmcgui.Dialog().select(texto(31710, "Marcadores"), opciones)
    if elegido < 0:
        return
    if elegido == 0:
        guardar(carpeta, nombre, ventana, marcadores)
        return

    marcador = marcadores[elegido - 1]
    accion = xbmcgui.Dialog().select(marcador["name"],
                                     [texto(31714, "Abrir"),
                                      texto(31723, "Renombrar"),
                                      texto(31715, "Borrar")])
    if accion == 0:
        # Escapado como hace $ESCINFO: la ruta va entre comillas y sin barras ni
        # comillas sueltas, para que no rompa los parámetros del builtin.
        ruta = marcador["path"].replace("\\", "\\\\").replace('"', '\\"')
        xbmc.executebuiltin(f'ActivateWindow({marcador["win"]},"{ruta}",return)')
    elif accion == 1:
        nuevo = xbmcgui.Dialog().input(texto(31722, "Nombre del marcador"),
                                       defaultt=marcador["name"])
        if nuevo:
            marcador["name"] = nuevo
            if not escribir(marcadores):
                avisar(texto(31719, "No se pudieron guardar los marcadores."))
    elif accion == 2:
        marcadores.remove(marcador)
        if escribir(marcadores):
            avisar(texto(31718, "Marcador borrado."))
        else:
            avisar(texto(31719, "No se pudieron guardar los marcadores."))


main()
