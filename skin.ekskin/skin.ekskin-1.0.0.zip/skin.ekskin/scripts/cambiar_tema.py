# -*- coding: utf-8 -*-
"""Cambia de tema y, si el ajuste está activo, reproduce su sonido una vez recargada la skin."""
import sys

import xbmc
import xbmcgui

import sonidos_tema

TEMAS = ("xp", "win7", "win10", "win11", "linux", "mac")
SONIDOS = {"95": "tema_95", "xp": "tema_xp", "win7": "tema_7", "win10": "tema_10",
           "win11": "tema_11", "linux": "tema_linux", "mac": "tema_mac"}
CERROJO = "ekskin.cambiando_tema"


def aplicar(tema, oscuro=None):
    casa = xbmcgui.Window(10000)
    eleccion = f"{tema}:{oscuro}"
    # Un doble clic repite la elección y se descarta; una elección distinta espera su turno
    if casa.getProperty(CERROJO) == eleccion:
        return
    monitor = xbmc.Monitor()
    for _ in range(150):
        if not casa.getProperty(CERROJO):
            break
        if monitor.waitForAbort(0.1):
            return
    casa.setProperty(CERROJO, eleccion)
    try:
        for otro in TEMAS:
            xbmc.executebuiltin(f"Skin.SetBool({otro}_theme,{'true' if otro == tema else 'false'})")
        if oscuro is not None:
            ajuste = f"{tema}_dark"
            xbmc.executebuiltin(f"Skin.SetBool({ajuste})" if oscuro else f"Skin.Reset({ajuste})")
        # Se espera a que termine la recarga: ReloadSkin descarga los sonidos de la interfaz, también
        # los de playSFX, y uno lanzado antes se corta a los 0,2 s o ni llega a sonar
        xbmc.executebuiltin("ReloadSkin()", True)
        if sonidos_tema.activado():
            if sonidos_tema.listos():
                xbmc.playSFX(sonidos_tema.ruta(SONIDOS[tema]))
            else:
                # Faltan WAV (borrados o versión nueva): se generan en otro script para no retener el cambio
                xbmc.executebuiltin("RunScript(special://skin/scripts/sonidos_tema.py,generar)")
    finally:
        casa.clearProperty(CERROJO)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in SONIDOS:
        aplicar(sys.argv[1])
