# -*- coding: utf-8 -*-
import os
import time

import xbmc

# Android no mata el proceso al cerrar: CXBMCApp::Stop avisa a la app y el
# cierre real lo decide Android (Application.cpp:2080-2082), de ahí que al
# reabrir enseguida la pantalla pueda quedar en negro.
#
# Un script lanzado por ruta no es un addon, y Kodi solo avisa a
# monitor.abortRequested() cuando el script es un addon (PythonInvoker.cpp:467-473
# en Kodi 21.2), así que aquí no hay aviso al que esperar y la espera es fija.
# En Stop() los ajustes se guardan en :2127-2140, después de cerrar el
# reproductor (:2092), así que 3 s dejan margen sin perderlos; el hilo principal
# no nos espera hasta :2189 y con un tope de 5 s (PythonInvoker.cpp:62,481).
ESPERA_ANTES_DE_MATAR = 3.0

xbmc.log("EKSkin: cierre forzado pedido", xbmc.LOGINFO)
xbmc.executebuiltin("Quit()")
try:
    time.sleep(ESPERA_ANTES_DE_MATAR)
finally:
    os._exit(0)
