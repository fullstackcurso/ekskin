# -*- coding: utf-8 -*-
import json

import xbmc
import xbmcgui


def texto(id_texto, por_defecto):
    # getLocalizedString solo ve los strings de la skin en algunas versiones de
    # Kodi; el respaldo evita dejar los diálogos en blanco.
    return xbmc.getLocalizedString(id_texto) or por_defecto


def main():
    titulo = texto(31701, "Volver a Espatuary")
    if xbmc.getCondVisibility("System.HasAddon(skin.espatuary)"):
        destino = "skin.espatuary"
    else:
        destino = "skin.estuary"

    if not xbmc.getCondVisibility(f"System.AddonIsEnabled({destino})"):
        aviso = texto(31702, "La skin de destino está deshabilitada. "
                             "Habilítala en Ajustes, Interfaz, Skin.")
        xbmcgui.Dialog().notification(titulo, aviso, xbmcgui.NOTIFICATION_WARNING, 6000)
        return

    if not xbmcgui.Dialog().yesno(titulo, texto(31704, "¿Cambiar de skin? Se cerrará EKSkin.")):
        return

    peticion = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Settings.SetSettingValue",
        "params": {"setting": "lookandfeel.skin", "value": destino},
    })
    try:
        respuesta = json.loads(xbmc.executeJSONRPC(peticion))
    except ValueError:
        respuesta = {}
    if "error" in respuesta or not respuesta.get("result"):
        aviso = texto(31703, "No se pudo cambiar la skin.")
        xbmcgui.Dialog().notification(titulo, aviso, xbmcgui.NOTIFICATION_ERROR, 6000)


main()
