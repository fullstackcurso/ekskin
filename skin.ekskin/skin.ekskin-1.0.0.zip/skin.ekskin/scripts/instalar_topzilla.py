# -*- coding: utf-8 -*-
import http.client
import io
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

TITULO = "EKSkin"
NOMBRE = "Topzilla"
ADDON_ID = "plugin.video.topzilla"
REPO_ID = "repository.topzilla"
REPO_URL = "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip"
FUENTE_MANUAL = "https://espatv.github.io/topzilla/"
MAX_REPO_ZIP = 50 * 1024 * 1024
MAX_ADDON_ZIP = 200 * 1024 * 1024
ESPERA_REPO_S = 20
INTERVALO_MS = 500
# urllib puede lanzar http.client.HTTPException (IncompleteRead, InvalidURL), que no es OSError.
ERRORES_DESCARGA = (ValueError, OSError, http.client.HTTPException, zipfile.BadZipFile)


class Cancelado(Exception):
    """Se pulsó Cancelar en el progreso: se termina sin aviso de error."""


def _log(mensaje, nivel=xbmc.LOGINFO):
    xbmc.log(f"[EKSkin] {mensaje}", nivel)


def _jsonrpc(metodo, params=None):
    peticion = {"jsonrpc": "2.0", "id": 1, "method": metodo}
    if params is not None:
        peticion["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(peticion)))
    except ValueError as error:
        _log(f"Respuesta JSON-RPC ilegible en {metodo}: {error}", xbmc.LOGWARNING)
        return {}


def _detalles_addon(addon_id):
    respuesta = _jsonrpc("Addons.GetAddonDetails",
                         {"addonid": addon_id, "properties": ["enabled"]})
    return respuesta.get("result", {}).get("addon")


def _activo():
    return xbmc.getCondVisibility(f"System.AddonIsEnabled({ADDON_ID})")


def _habilitar(addon_id):
    # Por JSON-RPC y no con el builtin EnableAddon, que pregunta sí/no cada vez que se
    # llama, aunque el add-on ya esté activo (AddonBuiltins.cpp:78 en Kodi 21.3).
    respuesta = _jsonrpc("Addons.SetAddonEnabled",
                         {"addonid": addon_id, "enabled": True})
    return respuesta.get("result") == "OK"


def _descargar(url, maximo):
    # GitHub ignora a urllib si no lleva User-Agent y responde 403 a veces.
    peticion = urllib.request.Request(url, headers={"User-Agent": "EKSkin"})
    with urllib.request.urlopen(peticion, timeout=30) as respuesta:
        datos = respuesta.read(maximo + 1)
    if len(datos) > maximo:
        raise ValueError(f"El archivo pasa de {maximo // (1024 * 1024)} MB")
    if not datos.startswith(b"PK"):
        raise ValueError("El archivo descargado no es un ZIP")
    return datos


def _descargar_texto(url):
    peticion = urllib.request.Request(url, headers={"User-Agent": "EKSkin"})
    with urllib.request.urlopen(peticion, timeout=20) as respuesta:
        return respuesta.read().decode("utf-8", "replace")


def _url_repo_actual():
    # La página de instalación manual enlaza el zip del repositorio con su versión en el nombre.
    pagina = _descargar_texto(FUENTE_MANUAL)
    patron = rf'href="([^"]*{re.escape(REPO_ID)}-(\d+(?:\.\d+)*)\.zip)"'
    candidatos = re.findall(patron, pagina)
    if not candidatos:
        return None
    enlace, _ = max(candidatos, key=lambda c: tuple(int(n) for n in c[1].split(".")))
    url = urllib.parse.urljoin(FUENTE_MANUAL, enlace)
    # El zip acaba extraído como código en Kodi: solo se acepta por https.
    return url if url.startswith("https://") else None


def _descargar_repo():
    # REPO_URL lleva la versión en el nombre; si el repositorio sube de versión y ese zip
    # desaparece, GitHub responde con error HTTP y se busca el zip vigente en la página.
    # Un fallo de red no es HTTPError y sale tal cual: la página tampoco se alcanzaría.
    try:
        return _descargar(REPO_URL, MAX_REPO_ZIP)
    except urllib.error.HTTPError as error:
        _log(f"{REPO_URL} respondió {error.code}; se busca el zip en {FUENTE_MANUAL}",
             xbmc.LOGWARNING)
        # Si la búsqueda también falla, el aviso enseña el error del zip, que es el que importa.
        try:
            url = _url_repo_actual()
        except (OSError, http.client.HTTPException) as fallo_pagina:
            _log(f"No se pudo leer {FUENTE_MANUAL}: {fallo_pagina}", xbmc.LOGWARNING)
            url = None
        if url is None:
            raise error
        return _descargar(url, MAX_REPO_ZIP)


def _extraer_seguro(zip_path, destino):
    # Comprueba que ninguna entrada del zip se salga de la carpeta de addons.
    destino_real = os.path.realpath(destino)
    with zipfile.ZipFile(zip_path) as archivo:
        for entrada in archivo.namelist():
            ruta = os.path.realpath(os.path.join(destino, entrada))
            if not ruta.startswith(destino_real + os.sep):
                raise ValueError(f"Ruta sospechosa en el ZIP: {entrada}")
        archivo.extractall(destino)


def _esperar_repo(progreso):
    # System.HasAddon solo pide que esté instalado, activo o no (AddonsGUIInfo.cpp:241-246).
    vueltas = ESPERA_REPO_S * 1000 // INTERVALO_MS
    for _ in range(vueltas):
        if progreso.iscanceled():
            raise Cancelado()
        if xbmc.getCondVisibility(f"System.HasAddon({REPO_ID})"):
            return True
        xbmc.sleep(INTERVALO_MS)
    return False


def _recuperar():
    if _detalles_addon(ADDON_ID) and _habilitar(ADDON_ID):
        xbmc.sleep(800)
        if _activo():
            return True
    carpeta = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/")
    if not os.path.isfile(os.path.join(carpeta, "addon.xml")):
        return False
    for _ in range(2):
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        if _detalles_addon(ADDON_ID) and _habilitar(ADDON_ID):
            xbmc.sleep(800)
            if _activo():
                return True
    return False


def _url_datadir():
    addon_xml = xbmcvfs.translatePath(f"special://home/addons/{REPO_ID}/addon.xml")
    if not os.path.isfile(addon_xml):
        return None
    with open(addon_xml, encoding="utf-8") as fichero:
        contenido = fichero.read()
    encontrado = re.search(r"<datadir[^>]*>\s*([^<\s]+)\s*</datadir>", contenido)
    if not encontrado:
        return None
    url = encontrado.group(1).strip()
    return url if url.endswith("/") else url + "/"


def _version_en_indice(indice):
    for patron in (
        f'<addon[^>]*\\bid="{re.escape(ADDON_ID)}"[^>]*\\bversion="([^"]+)"',
        f'<addon[^>]*\\bversion="([^"]+)"[^>]*\\bid="{re.escape(ADDON_ID)}"',
    ):
        encontrado = re.search(patron, indice)
        if encontrado:
            return encontrado.group(1)
    return None


def _dependencias(datos_zip):
    # Los <import> obligatorios del addon.xml del zip, sin los xbmc.* que ya trae Kodi.
    with zipfile.ZipFile(io.BytesIO(datos_zip)) as archivo:
        raiz = ET.fromstring(archivo.read(f"{ADDON_ID}/addon.xml"))
    return [imp.get("addon") for imp in raiz.iter("import")
            if imp.get("addon") and not imp.get("addon").startswith("xbmc.")
            and imp.get("optional", "").strip().lower() != "true"]


def _instalar_dependencias(dependencias):
    # Al descomprimir a mano, Kodi no instala las dependencias y activa el add-on igual
    # (AddonManager.cpp:936-940); Topzilla fallaría al importar requests. InstallAddon las
    # baja de los repositorios activos, el oficial de Kodi incluido, y pregunta antes.
    for dependencia in dependencias:
        detalles = _detalles_addon(dependencia)
        if detalles and detalles.get("enabled"):
            continue
        if detalles:
            _habilitar(dependencia)
        else:
            xbmc.executebuiltin(f"InstallAddon({dependencia})", True)
        detalles = _detalles_addon(dependencia)
        if not (detalles and detalles.get("enabled")):
            _log(f"Falta la dependencia {dependencia} de {NOMBRE}", xbmc.LOGWARNING)
            return False
    return True


def _instalar_zip_directo():
    # Alternativa al InstallAddon: baja el zip del addon del propio repositorio.
    try:
        datadir = _url_datadir()
        if not datadir or "127.0.0.1" in datadir or "localhost" in datadir:
            return False
        indice = _descargar_texto(datadir + "addons.xml")
        version = _version_en_indice(indice)
        if version is None:
            return False
        datos = _descargar(f"{datadir}{ADDON_ID}/{ADDON_ID}-{version}.zip", MAX_ADDON_ZIP)
        # Antes de extraer: si falta una dependencia, Topzilla no se deja a medias en disco.
        if not _instalar_dependencias(_dependencias(datos)):
            return False
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"),
                                f"{ADDON_ID}-{version}.zip")
        with open(zip_path, "wb") as fichero:
            fichero.write(datos)
        try:
            _extraer_seguro(zip_path, xbmcvfs.translatePath("special://home/addons/"))
        finally:
            os.remove(zip_path)
        return _recuperar()
    except ERRORES_DESCARGA + (KeyError, ET.ParseError) as error:
        _log(f"Fallo la instalación directa de {NOMBRE}: {error}", xbmc.LOGERROR)
        return False


def _instalar_directo_con_aviso():
    progreso = xbmcgui.DialogProgressBG()
    progreso.create(TITULO, f"Descargando {NOMBRE}...")
    try:
        return _instalar_zip_directo()
    finally:
        progreso.close()


def _instalar():
    progreso = xbmcgui.DialogProgress()
    progreso.create(TITULO, f"Descargando el repositorio de {NOMBRE}...")
    zip_path = None
    try:
        if not xbmc.getCondVisibility(f"System.HasAddon({REPO_ID})"):
            progreso.update(5, "Descargando el repositorio...")
            datos = _descargar_repo()
            zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"),
                                    f"{REPO_ID}.zip")
            with open(zip_path, "wb") as fichero:
                fichero.write(datos)
            progreso.update(20, "Extrayendo el repositorio...")
            _extraer_seguro(zip_path, xbmcvfs.translatePath("special://home/addons/"))
            progreso.update(35, "Registrando el repositorio en Kodi...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            if not _esperar_repo(progreso):
                raise RuntimeError(f"Kodi no registró el repositorio en {ESPERA_REPO_S} s")
        # Fuera del if: un repositorio instalado pero desactivado no se actualiza y Kodi
        # no encontraría Topzilla en él.
        repo = _detalles_addon(REPO_ID)
        if not (repo and repo.get("enabled")):
            progreso.update(55, "Activando el repositorio...")
            if not _habilitar(REPO_ID):
                raise RuntimeError("Kodi no activó el repositorio")
        progreso.update(65, "Actualizando el índice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)
        progreso.close()
        xbmcgui.Dialog().notification(TITULO, f"Confirma la instalación de {NOMBRE}",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        # Con espera: InstallAddon pregunta sí/no y, con sí, instala de forma modal
        # (AddonInstaller.cpp:264-273), así que al volver el resultado ya está decidido.
        xbmc.executebuiltin(f"InstallAddon({ADDON_ID})", True)
        if not (_activo() or _recuperar()):
            # Un "no" en la pregunta de Kodi y un fallo de la instalación llegan aquí igual,
            # así que la descarga directa se hace solo si se acepta.
            _log(f"{NOMBRE} no quedó instalado tras InstallAddon", xbmc.LOGWARNING)
            if not xbmcgui.Dialog().yesno(
                    TITULO, f"{NOMBRE} no se ha instalado. ¿Probar la descarga directa?"):
                return None
            if not _instalar_directo_con_aviso():
                return False
        xbmcgui.Dialog().notification(TITULO, f"{NOMBRE} instalado correctamente",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        return True
    except Cancelado:
        return None
    except ERRORES_DESCARGA + (RuntimeError,) as error:
        _log(f"Error instalando {NOMBRE}: {error}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(TITULO, f"No se pudo instalar {NOMBRE} automáticamente.\n\n{error}")
        return False
    finally:
        progreso.close()
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError as error:
                _log(f"No se pudo borrar {zip_path}: {error}", xbmc.LOGWARNING)


def _instrucciones():
    xbmcgui.Dialog().textviewer(
        TITULO,
        f"[B]Cómo instalar {NOMBRE} manualmente[/B]\n\n"
        "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos.\n\n"
        f"2. Ajustes - Explorador de archivos - Añadir fuente:\n   {FUENTE_MANUAL}\n\n"
        "3. Addons - Instalar desde un archivo zip - elige el zip del repositorio.\n\n"
        f"4. Addons - Instalar desde repositorio - {NOMBRE} - Instalar.")


def main():
    detalles = _detalles_addon(ADDON_ID)
    if detalles and detalles.get("enabled"):
        return
    if detalles:
        if not xbmcgui.Dialog().yesno(TITULO, "¿Activar Topzilla?"):
            return
        if _habilitar(ADDON_ID):
            xbmc.sleep(800)
        if _activo():
            return
        _log("No se pudo activar Topzilla", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(TITULO, "No se pudo activar Topzilla.")
        return
    if not xbmcgui.Dialog().yesno(TITULO,
                                  "Topzilla no está instalado. ¿Descargarlo e instalarlo?"):
        return
    # None es que se rechazó la descarga directa: no se insiste con las instrucciones.
    if _instalar() is False:
        _instrucciones()


main()
